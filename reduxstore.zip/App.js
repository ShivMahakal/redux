import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Cart from "./pages/Cart";
import Product from "./pages/Product";
import Navbar from "./components/Navbar";
import { Provider } from "react-redux";
import store from "../src/store/store";
import Register from "./pages/Register";
import Demo from "./pages/Demo";

function App() {
  return (
    <div>
      <Provider store={store}>
        {/* <Navbar /> */}
        <Routes>
          <Route path="/" element={<Home />} />

          <Route path="/cart" element={<Cart />} />
          <Route path="/register" element={<Register />} />
          <Route path="/demo" element={<Demo />} />
          <Route path="/product/:id" element={<Product />} />
        </Routes>
      </Provider>
    </div>
  );
}

export default App;
