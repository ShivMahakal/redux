import React, { useState } from "react";
import { AiFillEye, AiFillEyeInvisible } from "react-icons/ai";

const Demo = () => {
  const [showPassword, setShowPassword] = useState(false);
  const togglePassword = () => {
    setShowPassword(!showPassword);
  };
  return (
    <div className=" mx-auto px-2 lg:flex top-20 relative">
      <div className="hidden flex-1 items-center justify-center lg:visible lg:flex">
        <form
          //   onSubmit={handleSubmit}
          className="mx-auto mb-10	mt-4 w-[70%] rounded-md border-[1px]  border-gray-300 p-6 sm:px-10"
        >
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              className="relative mt-2 w-full rounded  py-3 pl-3 text-sm font-medium leading-none text-gray-800 border-[1px] border-b-slate-300"
            />
            {showPassword && (
              <div className="visible absolute right-0 bottom-2 mr-6">
                <AiFillEyeInvisible />
              </div>
            )}

            <div className="visible absolute right-0 bottom-2 mr-6">
              <AiFillEye size={20} onClick={togglePassword} />
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Demo;
