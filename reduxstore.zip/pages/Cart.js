import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { remove } from "../store/cartSlice";
const Cart = () => {
  const dispatch = useDispatch();
  const product = useSelector((state) => state.cart);

  const handleRemove = (productId) => {
    dispatch(remove(productId));
  };
  return (
    <div>
      <h3>Cart</h3>

      <div className="relative top-20 max-w-6xl	 mx-auto">
        {product?.map((item) => (
          <div
            className="flex   mx-auto items-center space-around shadow-lg border-[1px] border-indigo-800 rounded-lg py-4"
            key={item?.id}
          >
            <img src={item?.image} alt="" className=" h-[120px] mx-auto" />
            <h4>{item?.title}</h4>
            <h5 className="text-center">
              <span className="font-semibold">Rs.</span> {item.price}
            </h5>
            <button
              className="px-4 py-2 bg-indigo-500 text-white rounded-md mt-4 items-center justify-center border-[1px] mx-auto hover:border-[1px] border-indigo-900 hover:bg-white hover:text-black"
              onClick={() => handleRemove(item.id)}
            >
              Remove Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Cart;
