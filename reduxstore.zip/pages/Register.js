import React, { useState } from "react";
import { AiFillEye } from "react-icons/ai";
import { AiFillEyeInvisible } from "react-icons/ai";
import Bimage from "../images/Bicycle.png";
import logoimg from "../images/logo.png";
const Register = () => {
  const [passwordShown, setPasswordShown] = useState(false);
  const [loading, setLoading] = useState(false);
  const togglePassword = () => {
    setPasswordShown(!passwordShown);
  };
  return (
    <div className=" mx-auto px-2 lg:flex top-20 relative">
      <div className="hidden flex-1 items-center justify-center lg:visible lg:flex">
        <img src={Bimage} alt="banner-image" />
      </div>

      <div className="md:w-[100%] lg:w-[40%]">
        <div className="mx-auto flex w-[30%] items-center justify-center">
          <img src={logoimg} alt="logo" className="mx-auto" />
        </div>

        <form
          //   onSubmit={handleSubmit}
          className="mx-auto mb-10	mt-4 w-[70%] rounded-md border-[1px]  border-gray-300 p-6 sm:px-10"
        >
          <h1 className="text-center">Create Account</h1>
          <div className="mt-6">
            <label className="text-[18px]  font-extrabold uppercase leading-none text-gray-800	">
              Name
            </label>
            <input
              required={true}
              aria-label="Enter Your Name"
              role="input"
              type="text"
              name="name"
              className="mt-2 w-full rounded border py-3 pl-3 text-sm font-medium leading-none text-gray-800 focus:outline-none"
              //   value={user.name}
              //   onChange={inputValues}
            />

            <div className="mt-4">
              <label className="text-[18px]  font-extrabold uppercase leading-none text-gray-800	">
                Email
              </label>
              <input
                required={true}
                aria-label="Enter Your Email"
                role="input"
                type="email"
                className=" mt-2 w-full rounded border py-3 pl-3 text-sm font-medium leading-none text-gray-800 focus:outline-none"
                // value={user.email}
                // name="email"
                // onChange={inputValues}
                autoComplete="off"
                // onBlur={(e) => {
                //   if (
                //     /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(
                //       e.target.value
                //     )
                //   ) {
                //     return true;
                //   }
                // }}
              />
              <div className="mt-4  overflow-hidden">
                <label className="text-[18px]  font-extrabold uppercase leading-none text-gray-800	">
                  Password
                </label>
              </div>
              <div className="relative">
                <input
                  required={true}
                  aria-label="enter password"
                  role="input"
                  type={passwordShown ? "text" : "password"}
                  name="password"
                  className=" relative mt-2 w-full rounded border py-3 pl-3 text-sm font-medium leading-none text-gray-800 focus:outline-none"
                  //   value={user.password}
                  //   onChange={inputValues}
                />
                <div
                  className={`${
                    passwordShown
                      ? "visible absolute right-0 bottom-2 mr-6"
                      : "invisible absolute right-0 bottom-2 mr-6"
                  }`}
                >
                  <AiFillEyeInvisible size={20} onClick={togglePassword} />
                </div>
                <div
                  className={`${
                    setPasswordShown
                      ? "visible absolute right-0 bottom-2 mr-6 cursor-pointer"
                      : "invisible absolute right-0 bottom-2 mr-6 cursor-pointer"
                  }`}
                >
                  <AiFillEye size={20} onClick={togglePassword} />
                </div>
              </div>

              <div className="mt-4">
                <label className="text-[18px]  font-extrabold uppercase leading-none text-gray-800	">
                  Mobile Number
                </label>
              </div>
              <input
                required={true}
                aria-label="Enter  Mobile Number"
                role="input"
                type="tel"
                name="mobileNumber"
                className=" mt-2 w-full rounded border py-3 pl-3 text-sm font-medium leading-none text-gray-800 focus:outline-none"
                // value={user.mobileNumber}
                // onChange={inputValues}
                maxLength={10}
              />
            </div>
            <div>
              {loading ? (
                <button
                  type="submit"
                  aria-label="Sign Up"
                  className="mt-6 mb-4  w-full rounded border bg-[#FFB902] py-4 text-sm text-[18px]  font-bold leading-none text-white hover:bg-[#ffc430]"
                >
                  Create Account
                </button>
              ) : (
                <button
                  type="submit"
                  aria-label="Sign Up"
                  className="mt-6 mb-4  w-full rounded border bg-[#FFB902] py-4 text-sm text-[18px]  font-bold leading-none text-white hover:bg-[#ffc430]"
                >
                  Create Account
                </button>
              )}

              <div className="flex gap-4">
                <p className="font-semibold">Already have an account?</p>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;
