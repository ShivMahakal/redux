import React from "react";
import Stop from "../components/Stop";
// import Products from "../components/Products";

const Home = () => {
  return (
    <div>
      <section>
        {/* <h2>Products</h2> */}
        {/* <Products /> */}
        <Stop/>
      </section>
    </div>
  );
};

export default Home;
