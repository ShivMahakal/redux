import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";

const Product = () => {
  const [product, setProduct] = useState([]);
  const location = useLocation();

  // const id = location.pathname.split("/")[2];
  const { id } = useParams();

  useEffect(() => {
    const getProducts = async () => {
      try {
        const res = await axios.get(`https://fakestoreapi.com/products/${id}`);

        console.log(res, "Response");
        setProduct(res.data);
      } catch (error) {}
    };

    getProducts();
  }, [id]);
  return (
    <div>
      <>
        <div className="max-w-6xl flex mx-auto my-10  gap-4 px-4 mt-24 ">
          <div className="flex w-[10%] mt-24 flex-col gap-4">
            <img alt="product_img" src={product.image} className="w-[50px] " />
            <img alt="product_img" src={product.image} className="w-[50px] " />
          </div>

          <div className=" mx-auto mt-10 items-center justify-center px-4 ">
            <div className=" items-center justify-center mx-auto">
              <img
                alt="product_img"
                src={product.image}
                className=" w-[250px]"
              />
            </div>
          </div>
          <div className="items-center justify-center flex-1 mt-10">
            <h1 className="text-[28px]">{product.title}</h1>

            <p className="text-gray-600 w-[80%]">{product.description}</p>
          </div>
        </div>
      </>
    </div>
  );
};

export default Product;
