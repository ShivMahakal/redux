import React, { useEffect, useState } from "react";
import { add } from "../store/cartSlice";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "../store/productSlice";
import { Link } from "react-router-dom";

const Products = () => {
  const { data: products, status } = useSelector((state) => state.product);
  const dispatch = useDispatch();
  // const [products, setProducts] = useState([]);

  useEffect(() => {
    dispatch(fetchProducts());
    // const fetchProducts = async () => {
    //   const res = await fetch("https://fakestoreapi.com/products");

    //   const data = await res.json();

    //   console.log(data, "Data");
    //   setProducts(data);
    // };

    // fetchProducts();
  }, []);

  const handleAdd = (product) => {
    dispatch(add(product));
  };

  return (
    <div className="grid grid-cols-4 gap-8 container mx-auto px-6 relative top-20">
      {products.map((item) => (
        <div className="flex items-center justify-center shadow-lg border-[1px] border-indigo-800 rounded-lg py-4">
          <div
            key={item.id}
            className="items-center flex-col flex justify-center mx-auto"
          >
            <Link to={`product/${item.id}`}>
              <img src={item.image} alt="" className=" h-[120px] mx-auto" />
            </Link>
            <h4 className="w-[90%] mt-2 font-semibold text-center mx-auto">
              {item.title}
            </h4>
            <h5 className="text-center">
              <span className="font-semibold">Rs.</span> {item.price}
            </h5>
            <button
              className="px-4 py-2 bg-indigo-500 text-white rounded-md mt-4 items-center justify-center border-[1px] mx-auto hover:border-[1px] border-indigo-900 hover:bg-white hover:text-black"
              onClick={() => handleAdd(item)}
            >
              Add to Cart
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Products;
