import React, { useEffect, useState } from "react";
import { useRef } from "react";

const Stop = () => {
  const [time, setTime] = useState(0);
  const interval = useRef(null);
  // let [interval, setInterval] = useState(null);

  const handleStart = (e) => {
    interval.current = setInterval(() => {
      setTime((time) => time + 1);
    }, 1000);
  };

  const handleStop = (e) => {
    console.log(interval, "Interval");

    clearInterval(interval.current);
  };

  const handleReset = (e) => {
    clearInterval(interval);
    setTime(0);
  };

  return (
    <>
      <div className="gap-4 flex">
        <h1>StopWatch</h1>

        <button
          onClick={(e) => handleStart(e)}
          className="text-white bg-indigo-700 p-4"
        >
          Start{" "}
        </button>
        <button
          onClick={(e) => handleStop(e)}
          className="text-white bg-indigo-700 p-4"
        >
          Stop{" "}
        </button>
        <button
          onClick={(e) => handleReset(e)}
          className="text-white bg-indigo-700 p-4"
        >
          Reset{" "}
        </button>
      </div>
      <h3>{time}</h3>
    </>
  );
};

export default Stop;
