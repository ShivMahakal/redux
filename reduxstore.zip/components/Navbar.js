import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const Navbar = () => {
  const [openMenu, setOpenMenu] = useState(false);
  const items = useSelector((state) => state.cart);
  return (
    <div>
      <div className=" overflow-hidden">
        <nav className="fixed top-0 bg-indigo-400 w-full z-10 dark:bg-slate-900">
          <div className="container items-center mx-auto py-5 flex justify-between md:w-[1200px] px-5">
            <div className="flex items-center gap-2">
              <img src="./img/react.svg" alt="" className="w-10" />
              <span className="text-2xl font-semibold text-white">
                Redux Store
              </span>
            </div>

            <ul className="hidden md:flex space-x-10 text-green-900 font-semibold text-sm uppercase ">
              <li className="hover:text-white text-white">
                <Link to="/">Home</Link>
              </li>

              <li className="hover:white text-white">
                <Link to="/cart">Cart</Link>
              </li>
              <li className="hover:white text-white">
                <Link to="/">About Us</Link>
              </li>
              <li className="hover:white text-white">
                <Link to="/">Cart Items: {items.length}</Link>
              </li>
            </ul>

            <div
              id="hamburger"
              className="space-y-1 md:hidden cursor-pointer z-10 bg-indigo-500 pt-4 pb-4 pl-4 pr-4 rounded-full"
              onClick={() => setOpenMenu(!openMenu)}
            >
              <div className="w-6 h-0.5 bg-white"></div>
              <div className="w-6 h-0.5 bg-white"></div>
              <div className="w-6 h-0.5 bg-white"></div>
            </div>

            <ul
              id="menu"
              className={`${
                openMenu
                  ? "visible bg-indigo-900 absolute left-0 top-0 w-full h-screen p-10  text-white space-y-8  text-center"
                  : "hidden"
              }`}
            >
              <li className="hover:text-blue-800">
                <Link id="hLink" href="#">
                  Home
                </Link>
              </li>
              <li className="hover:text-blue-800">
                <Link id="hLink" href="#about">
                  About me
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default Navbar;
